//possibly not always working!!!
function checkNull(value){
	if (typeof value === "null" || typeof value === "undefined") {
		return true;
	} else {
		return false;
	}
}